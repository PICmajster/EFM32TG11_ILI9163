/*
 File Name:        :  pin_manager.c
 Device            :  EFM32TG11
 Compiler          :  Silicon Labs 4
 Created by        :  http://strefaarm.blogspot.com
 */

#include "em_chip.h"
#include "em_cmu.h"

void PIN_MANAGER_Init(void){

/* Configure pin for ILI9163 */

/* SDA  (Serial Data) */
   GPIO_PinModeSet(gpioPortA,               /* Port */
	                     0,                 /* Pin */
	                     gpioModePushPull,  /* Mode */
	                     0 );               /* Output value */
/* SCK  (Serial Clock) */
   GPIO_PinModeSet(gpioPortA,               /* Port */
	                     2,                 /* Pin */
	                     gpioModePushPull,  /* Mode */
	                     0 );               /* Output value */
/* A0   (Command / Data) */
   GPIO_PinModeSet(gpioPortA,               /* Port */
   	                     9,                 /* Pin */
   	                     gpioModePushPull,  /* Mode */
   	                     0 );               /* Output value */
/* RESET */
   GPIO_PinModeSet(gpioPortB,               /* Port */
   	                     11,                 /* Pin */
   	                     gpioModePushPull,  /* Mode */
   	                     0 );               /* Output value */



}
