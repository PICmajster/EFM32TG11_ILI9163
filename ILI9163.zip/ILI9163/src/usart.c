/*usart.c
  Device            :  EFM32TG11
  Compiler          :  Silicon Labs 4
  Created by        :  http://strefaarm.blogspot.com*/

#include "em_chip.h"
#include "em_cmu.h"
#include "usart.h"

#define SPI_BAUDRATE            1000000

void USART3_Init(void){

  /* Using synchronous (SPI) mode*/
  USART3->CTRL |=_USART_CTRL_SYNC_MASK ;
  /* Data is sent with the most significant bit first*/
  USART3->CTRL |= USART_CTRL_MSBF;
  /* Enable Master (SPI) mode and TX*/
  USART3->CMD |=USART_CMD_MASTEREN | USART_CMD_TXEN;
  /* Clearing old transfers */
  USART3->CMD |=USART_CMD_CLEARTX;
  /* Setting baudrate */
  USART3->CLKDIV = 128 * (cmuHFRCOFreq_26M0Hz / SPI_BAUDRATE - 2);
  /* disabling interrupts */
  /* Clear previous interrupts */
  USART3->IFC = _USART_IFC_MASK;
  USART3->IEN  = 0;
  /* Enable TX and CLK funcionality*/
  USART3->ROUTEPEN |= USART_ROUTEPEN_TXPEN | USART_ROUTEPEN_CLKPEN ;
  /* Set Location as TX and CLK */
  USART3->ROUTELOC0 |= USART_ROUTELOC0_TXLOC_LOC0 | USART_ROUTELOC0_CLKLOC_LOC0 ;

  }


/* sends buffer data using USART3 */
void USART3_sendBuffer(char* txBuffer)
{
  /* Sending the data */
  while(*txBuffer)
  {
    /* Waiting for the usart to be ready */
    while (!(USART3->STATUS & USART_STATUS_TXBL)) ;
    /* Writing next byte to USART */
      USART3->TXDATA = *txBuffer++;
  }

  /*Waiting for transmission of last byte */
  while (!(USART3->STATUS & USART_STATUS_TXC)) ;
}

/* sends byte data using USART3 */
uint8_t USART3_sendByte(char data)
{
	uint8_t receiveData;
	/* Waiting for the usart to be ready */
    while (!(USART3->STATUS & USART_STATUS_TXBL)) ;
    /* Writing next byte to USART */
    USART3->TXDATA = data;
    /*Waiting for transmission of last byte */
    while (!(USART3->STATUS & USART_STATUS_TXC)) ;
    receiveData = USART3->RXDATA ;
    return (receiveData);
}









