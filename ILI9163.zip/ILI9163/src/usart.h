/*
 File Name:        :  usart.h
 Device            :  EFM32TG11
 Compiler          :  Silicon Labs 4
 Created by        :  http://strefaarm.blogspot.com
 */

#ifndef SRC_USART_H_
#define SRC_USART_H_

void USART3_sendBuffer(char* txBuffer);
uint8_t USART3_sendByte(char data);
void USART3_Init(void);

#endif /* SRC_USART_H_ */
