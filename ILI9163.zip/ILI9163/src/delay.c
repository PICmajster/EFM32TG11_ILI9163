#include "em_chip.h"
#include "em_cmu.h"
#include "delay.h"


void delayMs(uint16_t milliseconds)
{
  /* Enable clock for TIMER0 */
  CMU->HFPERCLKEN0 |= CMU_HFPERCLKEN0_TIMER0;

  /* Set prescaler to maximum */
  TIMER0->CTRL = (TIMER0->CTRL & ~_TIMER_CTRL_PRESC_MASK) |  TIMER_CTRL_PRESC_DIV1024;

  /* Clear TIMER0 counter value */
  TIMER0->CNT = 0;

  /* Start TIMER0 */
  TIMER0->CMD = TIMER_CMD_START;

  /* Wait until counter value is over the target ms threshold */
  /* One TIMER0 count is 1024 (prescaler)/HFRCO frequency */
  /* The 1ms interval is about (HFRCO value - 1) TIMER0 count */
  /* For other families, the default HFRCO frequency is 26 MHz */
  while(TIMER0->CNT < 25*milliseconds){

   /* Do nothing, just wait */
  }

  /* Stop TIMER0 */
  TIMER0->CMD = TIMER_CMD_STOP;
}
