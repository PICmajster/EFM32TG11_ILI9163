/*
 File Name:        :  pin_manager.h
 Device            :  EFM32TG11
 Compiler          :  Silicon Labs 4
 Created by        :  http://strefaarm.blogspot.com
 */

#ifndef SRC_PIN_MANAGER_H_
#define SRC_PIN_MANAGER_H_

void PIN_MANAGER_Init(void);

#endif /* SRC_PIN_MANAGER_H_ */
