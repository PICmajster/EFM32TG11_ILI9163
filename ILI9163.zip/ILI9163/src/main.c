/************************************************************************
	main.c
    ILI9163 128x160 LCD library for EFM32TG11 Silicon Labs
    3.3 V
    strefaarm.blogspot.com
 ***********************************************************************/

#include "em_chip.h"
#include "em_cmu.h"
#include "ili9163.h"
#include "pin_manager.h"
#include "usart.h"

char txBuffer[] = "Witaj SPI";

int main(void)
{
  /* Chip errata */
  CHIP_Init();

  /* Enable clock HFRCO */
  CMU_HFRCOBandSet(cmuHFRCOFreq_26M0Hz);
  /* Enabling clock to GPIO*/
  CMU_ClockEnable(cmuClock_GPIO, true);
  /* Enabling clock to USART 3*/
  CMU_ClockEnable(cmuClock_USART3, true);

  PIN_MANAGER_Init();
  USART3_Init();
  RESET_OFF; /*Reset LCD high*/
  lcdInitialize();
  setRotation(2); /*ROTATION DISPLAY value 0...3*/
  lcdFillScreen(BLACK);
  //lcdFillRect(20, 20, 50, 50, RED);
  //lcdLine(20,50,100,50,LIME);
  //lcdPutCh('A',5,5,LIME,BLACK,2);
  //lcdPutS("ILI9163", 0, 50, ORANGE, BLACK, 3);
  //lcdBitmap(bitmap,93,128,0,0,BLACK,LIME);
  //lcdBitmap(bitmap1,128,30,0,0,BLACK,LIME);
  //lcdBitmap(bitmap3,128,30,0,31,YELLOW,RED);
  //lcdBitmap(bitmap2,128,30,0,62,LIGHT_GOLDENROD_YELLOW,BLUE);
  //lcdBitmap(bitmap4,128,30,0,93,RED,PINK);
  //lcdBitmap(bitmap5,128,30,0,124,WHITE,BLACK);
  //lcdCircle(50,50,30,ORANGE);
  //lcdFastHLine(10, 10, 50, LIME);
  //lcdFastVLine(10, 10, 50, LIME);
  //lcdFillScreen(LIME);
  //lcdFillRoundRect(10, 10, 80, 40, 10, LIME);
  //lcdRoundRect(10, 10, 70, 40, 10, LIME);
    lcdFillCircle(60, 80, 30, CYAN);
  //lcdPixel(20, 20, WHITE) ;
    lcdPutInteger(561, 5, 5, LIME, BLACK, 2); // display integer
  //lcdPutFloat(516.4, 5, 5, LIME, BLACK, 2); // display float 0.0 , size set 1 normal, > 1 bigger

  /* Infinite loop */
  while (1) {
  }
}

